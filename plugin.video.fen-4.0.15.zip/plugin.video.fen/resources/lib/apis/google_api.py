# -*- coding: utf-8 -*-
from caches.settings_cache import get_setting
from modules.utils import extract_json_object
# from modules.kodi_utils import logger


def models():
	return (
	'gemini-3.5-flash',
	'gemini-2.5-flash',
	'gemini-3.1-flash-lite',
	'gemini-2.5-flash-lite')

def model_payload(model_id, content):
	return {
	'gemini-3.5-flash': {
		'contents': [{'role': 'user', 'parts': [{'text': content}]}],
		'generationConfig': {'temperature': 0.7, 'responseMimeType': 'application/json'}},
	'gemini-2.5-flash': {
		'contents': [{'role': 'user', 'parts': [{'text': content}]}],
		'generationConfig': {'temperature': 0.7, 'responseMimeType': 'application/json'}},
	'gemini-3.1-flash-lite': {
		'contents': [{'role': 'user', 'parts': [{'text': content}]}],
		'generationConfig': {'temperature': 0.5, 'responseMimeType': 'application/json'}},
	'gemini-2.5-flash-lite': {
		'contents': [{'role': 'user', 'parts': [{'text': content}]}],
		'generationConfig': {'temperature': 0.5, 'responseMimeType': 'application/json'}}
		}[model_id]

def similar_prompt():
	return '''
Recommend EXACTLY LIMIT_HERE MEDIA_TYPE_HERE based on

MEDIA_TYPE: MEDIA_TYPE_HERE
TITLE: TITLE_HERE
YEAR: YEAR_HERE
PLOT: PLOT_HERE
GENRES: GENRES_HERE
KEYWORDS: KEYWORDS_HERE

If MEDIA_TYPE is "Movie" recommend ONLY movies otherwise recommend ONLY TV series / mini-series.
Respond ONLY with one JSON array in this exact shape. No other text.

{
  "recommendations": [
	{
	  "title": "Title 1",
	  "year": 2000,
	  "type": "Movie"  // or "Show"
	}
  ]
}

If a title would contain double quotes, replace them with single quotes (').
Don't include year in title.
'''.strip()

def mood_prompt():
	return  """
You are a brilliant cinema expert and a deeply intuitive psychological movie recommendation engine. Your task is to interpret a user's exact emotional state and provide highly 
targeted, accurate content recommendations.

The user has selected the following specific mood profile:
Mood Sub-Category: SUB_CATEGORY_NAME_HERE
Description: DESCRIPTION_HERE

STRICT MEDIA TYPE CONSTRAINT:
- You must ONLY recommend content where the format is: MEDIA_TYPE_HERE
- Do NOT mix formats. If 'Movie' is requested, do not include TV series or mini-series. If 'TV Show' is requested, do not include feature films.
- Attempt to only recommend Movies or TV Shows produced after the Year 2000.

CRITICAL RECOGNITION ELEMENTS:
- Thematic Anchors: ANCHORS_HERE
- Tonal Profile: TONES_HERE
- Cinematic Benchmarks (FORBIDDEN TO RECOMMEND): BENCHMARKS_HERE

### CORE PSYCHOLOGICAL BALANCING LAWS:
1. BENCHMARK BAN: Look at the 'Cinematic Benchmarks' list provided. You are STRICTLY FORBIDDEN from recommending those exact titles. Instead, treat those titles as perfect stylistic,
aesthetic, and narrative goals. Find other titles that feel mathematically similar in tone and structure.
2. ACCURACY TRAP: Ensure that the spelling of titles and their release years are 100% factual. Do not make up titles or guess release years.
3. FRESH BALANCE: Provide a diverse mix of widely known cinematic masterpieces and high-quality, hidden gems. Ensure the list has high-utility value.

Please provide a JSON array containing exactly LIMIT_HERE highly targeted MEDIA_TYPE_HERE recommendations based on this profile.

### CRITICAL OUTPUT RULE:
You must return ONLY a raw JSON array of objects. Do not include markdown code blocks (e.g. do NOT wrap the text in ```json ... ```), and do not include any introductory or
concluding conversational text. Your output must be instantly parseable by `json.loads()` in Python.

### Respond ONLY with one JSON array in this exact shape. No other text.

 {
  "recommendations": [
	{
	  "title": "Title 1",
	  "year": 2000,
	  "type": "Movie"  // or "Show"
	}
  ]
}
""".strip()

def response_parse(data):
	candidates = data.get('candidates') or []
	if not candidates: return {}
	parts = (candidates[0].get('content') or {}).get('parts') or []
	content = ''.join(part.get('text', '') for part in parts).strip()
	if not content: return {}
	content = extract_json_object(content)
	return content

def model_info_similar(model_id, media_type, meta, limit):
	payload = model_payload(model_id, make_similar_prompt(media_type, meta, limit))
	return {'similar': {'headers': {'Content-Type': 'application/json', 'x-goog-api-key': get_api()},
			'url': 'https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent' % model_id,
			'payload': payload, 'parse': response_parse}}

def make_similar_prompt(media_type, meta, limit):
	meta_get = meta.get
	title, year = meta_get('title').strip(), meta_get('year', '')
	plot, genre = meta_get('plot', '').strip(), ','.join([i for i in meta_get('genre') if i]) if meta_get('genre') else 'unknown'
	keywords = ','.join([i['name'] for i in meta_get('keywords', {}).get('keywords')]) if meta_get('keywords', {}).get('keywords') else ''
	prompt = similar_prompt()
	prompt = prompt.replace('MEDIA_TYPE_HERE', media_type).replace('TITLE_HERE', title).replace('YEAR_HERE', year)
	prompt = prompt.replace('PLOT_HERE', plot).replace('GENRES_HERE', genre).replace('KEYWORDS_HERE', keywords)
	prompt = prompt.replace('LIMIT_HERE', str(limit))
	return prompt

def model_info_mood(model_id, media_type, mood_info, limit):
	payload = model_payload(model_id, make_mood_prompt(media_type, mood_info, limit))
	return {'mood': {'headers': {'Content-Type': 'application/json', 'x-goog-api-key': get_api()},
			'url': 'https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent' % model_id,
			'payload': payload, 'parse': response_parse}}

def make_mood_prompt(media_type, mood_info, limit):
	sub_category = mood_info['sub_category']
	description = mood_info['description']
	anchors = ', '.join(mood_info['thematic_anchors'])
	tones = ', '.join(mood_info['tonal_profile'])
	benchmarks = ', '.join(mood_info['cinematic_benchmarks'])
	prompt = mood_prompt()
	prompt = prompt.replace('MEDIA_TYPE_HERE', media_type).replace('SUB_CATEGORY_NAME_HERE', sub_category).replace('DESCRIPTION_HERE', description)
	prompt = prompt.replace('ANCHORS_HERE', anchors).replace('TONES_HERE', tones).replace('BENCHMARKS_HERE', benchmarks)
	prompt = prompt.replace('LIMIT_HERE', str(limit))
	return prompt

def model_present(model_id):
	return model_id in models()

def get_api():
	return get_setting('fen.google_api')
