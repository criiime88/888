# -*- coding: utf-8 -*-

def get_years(start_year):
	from datetime import datetime
	current_year = datetime.now().year
	return [{'name': str(year), 'id': year} for year in range(current_year, start_year - 1, -1)]

def get_decades(start_decade):
	from datetime import datetime
	current_year = datetime.now().year
	current_decade = (current_year // 10) * 10
	return [{'name': '%ss' % decade, 'id': decade} for decade in range(current_decade, start_decade - 1, -10)]

def years_movies():
	return get_years(1900)

def years_tvshows():
	return get_years(1944)

def decades_movies():
	return get_decades(1900)

def decades_tvshows():
	return get_decades(1940)

def movie_certifications():
	return [
{'name': 'G', 'id': 'G'}, {'name': 'PG', 'id': 'PG'}, {'name': 'PG-13', 'id': 'PG-13'},
{'name': 'R', 'id': 'R'}, {'name': 'NC-17', 'id': 'NC-17'}, {'name': 'NR', 'id': 'NR'}
	]

def languages():
	return [
{'name': 'Arabic', 'id': 'ar'}, {'name': 'Bosnian', 'id': 'bs'}, {'name': 'Bulgarian', 'id': 'bg'}, {'name': 'Chinese', 'id': 'zh'}, {'name': 'Croatian', 'id': 'hr'},
{'name': 'Dutch', 'id': 'nl'}, {'name': 'English', 'id': 'en'}, {'name': 'Finnish', 'id': 'fi'}, {'name': 'French', 'id': 'fr'}, {'name': 'German', 'id': 'de'},
{'name': 'Greek', 'id': 'el'}, {'name': 'Hebrew', 'id': 'he'}, {'name': 'Hindi', 'id': 'hi'}, {'name': 'Hungarian', 'id': 'hu'}, {'name': 'Icelandic', 'id': 'is'},
{'name': 'Italian', 'id': 'it'}, {'name': 'Japanese', 'id': 'ja'}, {'name': 'Korean', 'id': 'ko'}, {'name': 'Macedonian', 'id': 'mk'}, {'name': 'Norwegian', 'id': 'no'},
{'name': 'Persian', 'id': 'fa'}, {'name': 'Polish', 'id': 'pl'}, {'name': 'Portuguese', 'id': 'pt'}, {'name': 'Punjabi', 'id': 'pa'}, {'name': 'Romanian', 'id': 'ro'},
{'name': 'Russian', 'id': 'ru'}, {'name': 'Serbian', 'id': 'sr'}, {'name': 'Slovenian', 'id': 'sl'}, {'name': 'Spanish', 'id': 'es'}, {'name': 'Swedish', 'id': 'sv'},
{'name': 'Turkish', 'id': 'tr'}, {'name': 'Ukrainian', 'id': 'uk'}, {'name': 'Vietnamese', 'id': 'vi'}
	]

def language_choices():
	return {
'None': 'None',              'Afrikaans': 'afr',            'Albanian': 'alb',             'Arabic': 'ara',
'Armenian': 'arm',           'Basque': 'baq',               'Bengali': 'ben',              'Bosnian': 'bos',
'Breton': 'bre',             'Bulgarian': 'bul',            'Burmese': 'bur',              'Catalan': 'cat',
'Chinese': 'chi',            'Croatian': 'hrv',             'Czech': 'cze',                'Danish': 'dan',
'Dutch': 'dut',              'English': 'eng',              'Esperanto': 'epo',            'Estonian': 'est',
'Finnish': 'fin',            'French': 'fre',               'Galician': 'glg',             'Georgian': 'geo',
'German': 'ger',             'Greek': 'ell',                'Hebrew': 'heb',               'Hindi': 'hin',
'Hungarian': 'hun',          'Icelandic': 'ice',            'Indonesian': 'ind',           'Italian': 'ita',
'Japanese': 'jpn',           'Kazakh': 'kaz',               'Khmer': 'khm',                'Korean': 'kor',
'Latvian': 'lav',            'Lithuanian': 'lit',           'Luxembourgish': 'ltz',        'Macedonian': 'mac',
'Malay': 'may',              'Malayalam': 'mal',            'Manipuri': 'mni',             'Mongolian': 'mon',
'Montenegrin': 'mne',        'Norwegian': 'nor',            'Occitan': 'oci',              'Persian': 'per',
'Polish': 'pol',             'Portuguese': 'por',           'Portuguese(Brazil)': 'pob',   'Romanian': 'rum',
'Russian': 'rus',            'Serbian': 'scc',              'Sinhalese': 'sin',            'Slovak': 'slo',
'Slovenian': 'slv',          'Spanish': 'spa',              'Swahili': 'swa',              'Swedish': 'swe',
'Syriac': 'syr',             'Tagalog': 'tgl',              'Tamil': 'tam',                'Telugu': 'tel',
'Thai': 'tha',               'Turkish': 'tur',              'Ukrainian': 'ukr',            'Urdu': 'urd',
'Vietnamese': 'vie'
	}

def movie_genres():
	return [
{'name': 'Action', 'id': '28', 'icon': 'genre_action'}, {'name': 'Adventure', 'id': '12', 'icon': 'genre_adventure'}, {'name': 'Animation', 'id': '16', 'icon': 'genre_animation'},
{'name': 'Comedy', 'id': '35', 'icon': 'genre_comedy'}, {'name': 'Crime', 'id': '80', 'icon': 'genre_crime'}, {'name': 'Documentary', 'id': '99', 'icon': 'genre_documentary'},
{'name': 'Drama', 'id': '18', 'icon': 'genre_drama'}, {'name': 'Family', 'id': '10751', 'icon': 'genre_family'}, {'name': 'Fantasy', 'id': '14', 'icon': 'genre_fantasy'},
{'name': 'History', 'id': '36', 'icon': 'genre_history'}, {'name': 'Horror', 'id': '27', 'icon': 'genre_horror'}, {'name': 'Music', 'id': '10402', 'icon': 'genre_music'},
{'name': 'Mystery', 'id': '9648', 'icon': 'genre_mystery'}, {'name': 'Romance', 'id': '10749', 'icon': 'genre_romance'},
{'name': 'Science Fiction', 'id': '878', 'icon': 'genre_scifi'}, {'name': 'TV Movie', 'id': '10770', 'icon': 'genre_soap'}, {'name': 'Thriller', 'id': '53', 'icon': 'genre_thriller'},
{'name': 'War', 'id': '10752', 'icon': 'genre_war'}, {'name': 'Western', 'id': '37', 'icon': 'genre_western'}
	]

def tvshow_genres():
	return [
{'name': 'Action & Adventure', 'id': '10759', 'icon': 'genre_action'}, {'name': 'Animation', 'id': '16', 'icon': 'genre_animation'},
{'name': 'Comedy', 'id': '35', 'icon': 'genre_comedy'}, {'name': 'Crime', 'id': '80', 'icon': 'genre_crime'}, {'name': 'Documentary', 'id': '99', 'icon': 'genre_documentary'},
{'name': 'Drama', 'id': '18', 'icon': 'genre_drama'}, {'name': 'Family', 'id': '10751', 'icon': 'genre_family'}, {'name': 'Kids', 'id': '10762', 'icon': 'genre_kids'},
{'name': 'Mystery', 'id': '9648', 'icon': 'genre_mystery'}, {'name': 'News', 'id': '10763', 'icon': 'genre_news'}, {'name': 'Reality', 'id': '10764', 'icon': 'genre_reality'},
{'name': 'Sci-Fi & Fantasy', 'id': '10765', 'icon': 'genre_scifi'}, {'name': 'Soap', 'id': '10766', 'icon': 'genre_soap'}, {'name': 'Talk', 'id': '10767', 'icon': 'genre_talk'},
{'name': 'War & Politics', 'id': '10768', 'icon': 'genre_war'}, {'name': 'Western', 'id': '37', 'icon': 'genre_western'}
	]

def movie_sorts():
	return [
{'name': 'Popularity (asc)', 'id': '&sort_by=popularity.asc'}, {'name': 'Popularity (desc)', 'id': '&sort_by=popularity.desc'},
{'name': 'Release Date (asc)', 'id': '&sort_by=primary_release_date.asc'}, {'name': 'Release Date (desc)', 'id': '&sort_by=primary_release_date.desc'},
{'name': 'Total Revenue (asc)', 'id': '&sort_by=revenue.asc'}, {'name': 'Total Revenue (desc)', 'id': '&sort_by=revenue.desc'},
{'name': 'Title (asc)', 'id': '&sort_by=original_title.asc'}, {'name': 'Title (desc)', 'id': '&sort_by=original_title.desc'},
{'name': 'Rating (asc)', 'id': '&sort_by=vote_average.asc'}, {'name': 'Rating (desc)', 'id': '&sort_by=vote_average.desc'},
{'name': 'Random', 'id': '[random]'}
	]

def tvshow_sorts():
	return [
{'name': 'Popularity (asc)', 'id': '&sort_by=popularity.asc'}, {'name': 'Popularity (desc)', 'id': '&sort_by=popularity.desc'},
{'name': 'First Aired (asc)', 'id': '&sort_by=first_air_date.asc'}, {'name': 'First Aired (desc)', 'id': '&sort_by=first_air_date.desc'},
{'name': 'Rating (asc)', 'id': '&sort_by=vote_average.asc'}, {'name': 'Rating (desc)', 'id': '&sort_by=vote_average.desc'},
{'name': 'Random', 'id': '[random]'}
	]

def discover_items():
	return {
'with_year_start': {'label': 'Year Start', 'key': 'with_year_start', 'display_key': 'with_year_start_display', 'action': 'years',
'url_insert_movie': '&primary_release_date.gte=%s-01-01', 'url_insert_tvshow': '&first_air_date.gte=%s-01-01', 'name_value': ' | %s onwards', 'icon': 'calender'},
'with_year_end': {'label': 'Year End', 'key': 'with_year_end', 'display_key': 'with_year_end_display', 'action': 'years',
'url_insert_movie': '&primary_release_date.lte=%s-12-31', 'url_insert_tvshow': '&first_air_date.lte=%s-12-31', 'name_value': ' | up to %s', 'icon': 'calender'},
'with_genres': {'label': 'With Genres', 'key': 'with_genres', 'display_key': 'with_genres_display', 'action': 'genres',
'url_insert': '&with_genres=%s', 'name_value': ' | %s', 'icon': 'genres'},
'without_genres': {'label': 'Without Genres', 'key': 'without_genres', 'display_key': 'without_genres_display', 'action': 'genres',
'url_insert': '&without_genres=%s', 'name_value': ' | exclude %s', 'icon': 'genres'},
'with_certification': {'label': 'Certification', 'key': 'with_certification', 'display_key': 'with_certification_display', 'action': 'certifications',
'url_insert': '&certification_country=US&certification=%s', 'name_value': ' | %s', 'limited': 'movie', 'icon': 'certifications'},
'with_certification_and_lower': {'label': 'Certification (& lower)', 'key': 'with_certification_and_lower', 'display_key': 'with_certification_and_lower_display',
'action': 'certification_and_lowers', 'url_insert': '&certification_country=US&certification.lte=%s', 'name_value': ' | %s', 'limited': 'movie', 'icon': 'certifications'},
'with_language': {'label': 'Language', 'key': 'with_language', 'display_key': 'with_language_display', 'action': 'languages',
'url_insert': '&with_original_language=%s', 'name_value': ' | %s', 'icon': 'languages'},	
'with_keywords': {'label': 'With Keywords', 'key': 'with_keywords', 'display_key': 'with_keywords_display', 'action': 'keywords',
'url_insert': '&with_keywords=%s', 'name_value': ' | Keywords: %s', 'icon': 'fantasy'},
'with_rating': {'label': 'Minimum Rating', 'key': 'with_rating', 'display_key': 'with_rating_display', 'action': 'ratings',
'url_insert': '&vote_average.gte=%s', 'name_value': ' | %s+', 'icon': 'most_watched'},
'with_rating_votes': {'label': 'Minimum Number of Votes', 'key': 'with_rating_votes', 'display_key': 'with_rating_votes_display', 'action': 'votes',
'url_insert': '&vote_count.gte=%s', 'name_value': ' | %s votes', 'icon': 'most_voted'},
'with_cast': {'label': 'Include Cast', 'key': 'with_cast', 'display_key': 'with_cast_display', 'action': 'casts',
'url_insert': '&with_cast=%s', 'name_value': ' | with %s', 'limited': 'movie', 'icon': 'people'},
'with_sort': {'label': 'Sort By', 'key': 'with_sort', 'display_key': 'with_sort_display', 'action': 'sort',
'url_insert': '%s', 'name_value': ' | %s', 'icon': 'lists'},
'with_released': {'label': 'Released Only', 'key': 'with_released', 'display_key': 'with_released_display', 'action': 'released',
'url_insert_movie': '&primary_release_date.lte=%s', 'url_insert_tvshow': '&include_null_first_air_dates=false&first_air_date.lte=%s', 'name_value': ' | Released Only', 'icon': 'dvd'},
'with_adult': {'label': 'Include Adult', 'key': 'with_adult', 'display_key': 'with_adult_display', 'action': 'adult',
'url_insert': '&include_adult=%s', 'name_value': ' | Include Adult', 'limited': 'movie', 'icon': 'romance'},
	}

def color_palette():
	return [
'FFFFFFE3', 'FFFFFAE6', 'FFFEF5E6', 'FFFEF0E5', 'FFFEEBE5', 'FFFFEFEF', 'FFFFE6EA', 'FFFFE6F1', 'FFFEE6F4', 'FFFFE6FB', 'FFFEE6FE', 'FFFAE6FF', 'FFF4E6FF', 'FFF0E6FF', 'FFEAE7FC',
'FFE6E7FC', 'FFE6EBFF', 'FFE7F0FF', 'FFE7F5FF', 'FFE7FAFF', 'FFE6FFFF', 'FFE6FFFB', 'FFE7FEF4', 'FFE7FFF1', 'FFE6FFEA', 'FFE7FFE7', 'FFEBFFF3', 'FFF1FFE6', 'FFF5FFE6', 'FFFBFFE6',
'FFFFFFFF', 'FFFFFFCB', 'FFFEFACA', 'FFFFEACB', 'FFFFE0CC', 'FFFED6CC', 'FFFFCACD', 'FFFFCCD5', 'FFFFCDE0', 'FFFFCCEB', 'FFFFCBF5', 'FFFECCFD', 'FFF6CBFF', 'FFECCCFE', 'FFE0CCFF',
'FFD6CCFE', 'FFCCCCFE', 'FFCDD6FF', 'FFCAE1FF', 'FFCCEBFF', 'FFCEF4FD', 'FFCAFFFF', 'FFCCFFF6', 'FFCBFEEB', 'FFCCFFE0', 'FFCCFFD6', 'FFCDFFCC', 'FFD7FFCB', 'FFE1FFCD', 'FFEBFFCC',
'FFF5FFCB', 'FFEFEFEF', 'FFFEFFB3', 'FFFFF1B2', 'FFFFE0B2', 'FFFDD2B2', 'FFFFC2B3', 'FFFFB3B3', 'FFFFB2C2', 'FFFFB3D1', 'FFFFB3E1', 'FFFFB2F4', 'FFFFB3FE', 'FFF0B3FF', 'FFE1B2FF',
'FFD2B3FF', 'FFC1B3FE', 'FFB4B3FF', 'FFB3C1FE', 'FFB2D1FF', 'FFB3E0FF', 'FFB2F0FF', 'FFB3FFFF', 'FFB3FFF0', 'FFB4FFE0', 'FFB3FFD1', 'FFB4FEC3', 'FFB3FFB4', 'FFC2FFB2', 'FFD1FFB4',
'FFE0FFB3', 'FFF1FFB4', 'FFE0E0E0', 'FFFEFF99', 'FFFFEB9A', 'FFFED699', 'FFFFC299', 'FFFFAD98', 'FFFF9899', 'FFFF99AE', 'FFFF99C1', 'FFFE99D5', 'FFFF99EC', 'FFFF99FF', 'FFEB99FF',
'FFD699FF', 'FFC299FF', 'FFAE99FF', 'FF9A99FF', 'FF98ADFE', 'FF9AC2FF', 'FF98D6FF', 'FF99EBFF', 'FF99FFFF', 'FF99FFEA', 'FF99FFD7', 'FF9AFFC3', 'FF99FFAC', 'FF99FF99', 'FFADFF99',
'FFC2FF98', 'FFD6FF99', 'FFEAFF98', 'FFD0D0D0', 'FFFFFF80', 'FFFFE681', 'FFFFCC80', 'FFFFB381', 'FFFF9980', 'FFFE8081', 'FFFF8199', 'FFFF80B3', 'FFFF80CD', 'FFFF80E7', 'FFFC81FE',
'FFE680FF', 'FFCC7FFF', 'FFB380FF', 'FF9980FF', 'FF807FFE', 'FF8099FE', 'FF7FB3FF', 'FF80CCFE', 'FF80E6FF', 'FF7FFFFE', 'FF7FFEE0', 'FF80FFCC', 'FF80FFB2', 'FF80FF98', 'FF81FF81',
'FF99FF80', 'FFB3FF80', 'FFCCFF80', 'FFE6FF80', 'FFC0C0C0', 'FFFFFF6B', 'FFFEE066', 'FFFFC267', 'FFFFA366', 'FFFF8566', 'FFFF6766', 'FFFF6685', 'FFFF66A4', 'FFFF66C1', 'FFFF66E0',
'FFFF66FF', 'FFE166FF', 'FFC366FF', 'FFA366FF', 'FF8566FF', 'FF6665FE', 'FF6785FF', 'FF66A3FE', 'FF65C2FF', 'FF65E0FF', 'FF65FFFF', 'FF66FFE0', 'FF65FFC1', 'FF66FFA4', 'FF65FF85',
'FF66FF66', 'FF84FF66', 'FFA2FF66', 'FFC2FF66', 'FFE0FF66', 'FFAFAFAF', 'FFFFFF4D', 'FFFFDB4E', 'FFFFB84E', 'FFFF944C', 'FFFF714D', 'FFFF4D4D', 'FFFF4D6F', 'FFFE4D93', 'FFFE4DB7',
'FFFE4DDB', 'FFFF4DFF', 'FFDC4DFF', 'FFB84DFF', 'FF944EFF', 'FF704DFF', 'FF4D4CFF', 'FF4D70FE', 'FF4D94FE', 'FF4DB8FF', 'FF4DDBFF', 'FF4DFFFF', 'FF4DFFDB', 'FF4EFFB9', 'FF4EFF95',
'FF4DFE70', 'FF4CFF4C', 'FF70FF4D', 'FF94FF4D', 'FFB8FE4D', 'FFDAFF4D', 'FF8C8C8C', 'FFFFFF33', 'FFFFD634', 'FFFFAD33', 'FFFF8532', 'FFFF5C33', 'FFFF3334', 'FFFF335C', 'FFFF3287',
'FFFF33AE', 'FFFF33D6', 'FFFE33FF', 'FFD633FE', 'FFAD34FF', 'FF8534FF', 'FF5D33FF', 'FF3233FF', 'FF325CFE', 'FF3285FF', 'FF33ADFF', 'FF33D6FF', 'FF33FFFE', 'FF32FFD6', 'FF34FFAD',
'FF33FF84', 'FF32FF5C', 'FF34FF33', 'FF5CFF34', 'FF85FE33', 'FFADFE33', 'FFD5FF33', 'FF7C7C7C', 'FFFFFF19', 'FFFFD119', 'FFFFA418', 'FFFF751A', 'FFFF4719', 'FFFF1919', 'FFFF1947',
'FFFF1874', 'FFFF19A3', 'FFFF19D1', 'FFFF19FF', 'FFD019FF', 'FFA219FF', 'FF751AFE', 'FF4719FF', 'FF1819FF', 'FF1947FF', 'FF1974FF', 'FF19A3FE', 'FF18D1FF', 'FF19FFFF', 'FF19FFD1',
'FF19FFA4', 'FF18FF75', 'FF19FF47', 'FF19FF19', 'FF48FF19', 'FF76FF19', 'FFA3FE1A', 'FFD1FF19', 'FF6B6B6B', 'FFFFFF00', 'FFFFCC00', 'FFFE9900', 'FFFF6600', 'FFFF3300', 'FFFE0000',
'FFFE0032', 'FFFF0066', 'FFFF0198', 'FFFF00CC', 'FFFF00FE', 'FFCC00FF', 'FF9A00FF', 'FF6601FF', 'FF3300FF', 'FF0000FE', 'FF0033FF', 'FF0166FF', 'FF0097FE', 'FF00CCFF', 'FF00FFFF',
'FF01FFCD', 'FF00FF99', 'FF00FE67', 'FF00FF33', 'FF00FF01', 'FF33FF00', 'FF65FF00', 'FF99FE00', 'FFCCFF00', 'FF5D5D5D', 'FFE8E500', 'FFE6B800', 'FFE68B00', 'FFE65C01', 'FFE72E00',
'FFE60000', 'FFE6002E', 'FFE6005B', 'FFE80183', 'FFE600B8', 'FFE600E6', 'FFB700E6', 'FF8900E6', 'FF5C01E5', 'FF2E00E6', 'FF0000E6', 'FF012EE1', 'FF005BE7', 'FF008AE5', 'FF00B8E6',
'FF00E6E6', 'FF00E6B7', 'FF00E78B', 'FF00E65F', 'FF00E532', 'FF00E600', 'FF2FE600', 'FF5DE600', 'FF8AE501', 'FFB8E600', 'FF4F4F4F', 'FFCDCC00', 'FFCDA301', 'FFCA7B02', 'FFCC5200',
'FFCC2900', 'FFCC0001', 'FFCD0029', 'FFCE0052', 'FFCC007B', 'FFCD00A3', 'FFCB00CC', 'FFA300CB', 'FF7A01CC', 'FF5201CC', 'FF2A00D0', 'FF0000CC', 'FF0029CB', 'FF0052CC', 'FF007ACD',
'FF00A3CC', 'FF00CCCB', 'FF00CCA3', 'FF01CC7A', 'FF03CB51', 'FF00CC29', 'FF01CC00', 'FF29CC01', 'FF52CB00', 'FF7ACB00', 'FFA2CC00', 'FF434343', 'FFB4B300', 'FFB38E00', 'FFB36B00',
'FFB34700', 'FFB32501', 'FFB30101', 'FFB40025', 'FFB40047', 'FFB4006B', 'FFB5008B', 'FFB300B3', 'FF8F00B2', 'FF6B00B2', 'FF4700B4', 'FF2300B2', 'FF0000B2', 'FF0025B4', 'FF0047B3',
'FF006BB3', 'FF008EB2', 'FF00B3B2', 'FF00B38E', 'FF00B36C', 'FF00B346', 'FF00B324', 'FF00B300', 'FF24B301', 'FF47B200', 'FF6CB201', 'FF90B301', 'FF373737', 'FF999A00', 'FF987A00',
'FF995C01', 'FF9A3D00', 'FF9A1F00', 'FF990100', 'FF99001F', 'FF9A003E', 'FF99005B', 'FF9A007A', 'FF990099', 'FF7B0099', 'FF5D0099', 'FF3D0099', 'FF1F0099', 'FF000098', 'FF011F99',
'FF003D98', 'FF005C99', 'FF007A99', 'FF009999', 'FF00997A', 'FF00995B', 'FF00993E', 'FF00991F', 'FF009900', 'FF1E9900', 'FF3C9900', 'FF5C9900', 'FF7A9900', 'FF2E2E2E', 'FF7F8000',
'FF7F6601', 'FF804C00', 'FF803201', 'FF801A01', 'FF800000', 'FF800019', 'FF800033', 'FF80004B', 'FF810065', 'FF81007F', 'FF660080', 'FF4C007F', 'FF33007F', 'FF1A0080', 'FF010080',
'FF011A7F', 'FF003480', 'FF004C80', 'FF00667F', 'FF008081', 'FF008067', 'FF037F4B', 'FF008033', 'FF00801B', 'FF008001', 'FF1A8000', 'FF338000', 'FF4C8001', 'FF668100', 'FF242424',
'FF656600', 'FF675201', 'FF653D00', 'FF672900', 'FF661400', 'FF660000', 'FF660015', 'FF660028', 'FF65003C', 'FF660053', 'FF660066', 'FF550069', 'FF3D0067', 'FF290066', 'FF150067',
'FF010066', 'FF001465', 'FF012966', 'FF003D66', 'FF005267', 'FF006766', 'FF006651', 'FF00663E', 'FF01662A', 'FF006613', 'FF006600', 'FF146600', 'FF296600', 'FF3D6600', 'FF516600',
'FF181818', 'FF4B4C00', 'FF4C3E01', 'FF4D2E00', 'FF4C1F00', 'FF4D0F00', 'FF4C0000', 'FF4C000F', 'FF4B001F', 'FF4C002E', 'FF4C003E', 'FF4C004B', 'FF3D004D', 'FF2E004B', 'FF1F004C',
'FF0E004B', 'FF01004C', 'FF000E4B', 'FF001F4D', 'FF012E4D', 'FF003D4C', 'FF004C4C', 'FF004D3D', 'FF004C2E', 'FF004C1E', 'FF004C0E', 'FF004C01', 'FF0F4C00', 'FF204C01', 'FF2D4C00',
'FF3E4C01', 'FF000000'
	]

def moods():
	return {
	'Restless & Hyperactive': {
		'High-Octane Blockbusters':
			{'description': 'You want a frantic heart rate, non-stop stunts, and massive cinematic momentum.',
			'thematic_anchors': ['car chases', 'high-speed racing', 'massive explosions', 'stunt-heavy set pieces'],
			'tonal_profile': ['adrenaline-fueled', 'fast-paced', 'spectacular', 'relentless'],
			'cinematic_benchmarks': ['Mad Max: Fury Road (2015)', 'Mission: Impossible - Fallout (2018)', 'Speed (1994)']},
		'Aggressive & Cathartic':
			{'description': 'Release bottled-up anger or frustration watching raw, bone-crunching physical combat.',
			'thematic_anchors': ['hand-to-hand combat', 'martial arts brawls', 'close-quarters violence', 'visceral choreography'],
			'tonal_profile': ['brutal', 'raw', 'intense', 'gritty', 'uncompromising'],
			'cinematic_benchmarks': ['John Wick (2014)', 'The Raid: Redemption (2011)', 'Fight Club (1999)']},
		'Competitive Rivalry':
			{'description': 'Feel driven by the intense stakes of winning, losing, tournaments, and underdogs.',
			'thematic_anchors': ['sports tournaments', 'bitter rivalries', 'underdog arcs', 'championship finals'],
			'tonal_profile': ['motivational', 'triumphant', 'high-stakes', 'passionate'],
			'cinematic_benchmarks': ['Whiplash (2014)', 'Warrior (2011)', 'Rush (2013)']},
		'Outlaw Escapism':
			{'description': 'Channel your rule-breaking energy into fast-paced, high-stakes heist thrillers and criminal runs.',
			'thematic_anchors': ['bank robberies', 'elaborate heists', 'getaway driving', 'criminal syndicates'],
			'tonal_profile': ['slick', 'thrilling', 'rebellious', 'clever', 'fast-moving'],
			'cinematic_benchmarks': ['Baby Driver (2017)', 'Heat (1995)', 'Ocean\'s Eleven (2001)']},
		'Unstoppable One-Man Army':
			{'description': 'Feel powerful and deeply confident tracking an unstoppable badass righting wrongs against impossible odds.',
			'thematic_anchors': ['lone vigilantes', 'elite assassins', 'retribution runs', 'one-vs-many combat'],
			'tonal_profile': ['empowering', 'badass', 'confident', 'ruthless'],
			'cinematic_benchmarks': ['Taken (2008)', 'The Equalizer (2014)', 'Man on Fire (2004)']},
		'Vengeful Payback':
			{'description': 'Harbor some spite and watch scores get settled with ruthless, calculated precision.',
			'thematic_anchors': ['vendettas', 'calculated revenge plots', 'score-settling', 'vigilante justice'],
			'tonal_profile': ['spiteful', 'calculated', 'cold', 'satisfying', 'grim'],
			'cinematic_benchmarks': ['Kill Bill: Vol. 1 (2003)', 'Promising Young Woman (2020)', 'The Count of Monte Cristo (2002)']},
		'High-Stakes Survival':
			{'description': 'Match your internal jitteriness with a nail-biting ticking clock and life-or-death survival scenarios.',
			'thematic_anchors': ['ticking-clock scenarios', 'trapped characters', 'hostage situations', 'countdown devices'],
			'tonal_profile': ['suspenseful', 'claustrophobic', 'frantic', 'anxiety-inducing'],
			'cinematic_benchmarks': ['Uncut Gems (2019)', 'Captain Phillips (2013)', '127 Hours (2010)']},
		'Kinetic Sensory Overload':
			{'description': 'Drown out your thoughts with chaotic, hyper-fast pacing and vibrant, stylized audio-visual frenzy.',
			'thematic_anchors': ['stylised audio-visuals', 'hyper-fast editing', 'neon aesthetics', 'frenetic pacing'],
			'tonal_profile': ['manic', 'vibrant', 'chaotic', 'dazzling', 'psychedelic'],
			'cinematic_benchmarks': ['Everything Everywhere All at Once (2022)', 'Spider-Man: Into the Spider-Verse (2018)', 'Crank (2006)']},
		'Dystopian Rebellion':
			{'description': 'Defy corrupt power structures and fight back against an oppressive, high-tech establishment.',
			'thematic_anchors': ['cyberpunk landscapes', 'anti-establishment uprisings', 'totalitarian regimes', 'underground resistance'],
			'tonal_profile': ['defiant', 'revolutionary', 'futuristic', 'gritty'],
			'cinematic_benchmarks': ['The Matrix (1999)', 'V for Vendetta (2005)', 'The Hunger Games (2012)']},
		'Mindless Popcorn Fun':
			{'description': 'Completely switch off your brain with campy, loud, high-energy disaster and monster spectacles.',
			'thematic_anchors': ['creature features', 'alien invasions', 'global disasters', 'city-level destruction'],
			'tonal_profile': ['campy', 'fun', 'loud', 'escapist', 'unpretentious'],
			'cinematic_benchmarks': ['Godzilla vs. Kong (2021)', 'Independence Day (1996)', '2012 (2009)']}
	},
	'Joyful & Comfort Seeking': {
		'Serene & Cozy':
			{'description': 'You want a warm blanket for the soul—low stakes, gentle humor, and maximum comfort.',
			'thematic_anchors': ['low stakes plots', 'slow-paced living', 'gentle humor', 'heartwarming slice-of-life'],
			'tonal_profile': ['cozy', 'wholesome', 'peaceful', 'charming', 'soothing'],
			'cinematic_benchmarks': ['Paddington 2 (2017)', 'Amélie (2001)', 'My Neighbor Totoro (1988)']},
		'Charming Rom-Coms':
			{'description': 'You want lighthearted romantic butterfly feelings, witty banter, and happy endings.',
			'thematic_anchors': ['witty banter', 'meet-cutes', 'romantic gestures', 'happily-ever-afters'],
			'tonal_profile': ['lighthearted', 'romantic', 'sparkling', 'sweet', 'flirtatious'],
			'cinematic_benchmarks': ['About Time (2013)', 'The Proposal (2009)', 'Notting Hill (1999)']},
		'Whimsical & Magical':
			{'description': 'Escape into a playful, imaginative world full of lighthearted wonder and quirky charm.',
			'thematic_anchors': ['playful magic', 'fairytale worlds', 'eccentric characters', 'childlike wonder'],
			'tonal_profile': ['whimsical', 'quirky', 'imaginative', 'fanciful', 'magical'],
			'cinematic_benchmarks': ['The Princess Bride (1987)', 'Hugo (2011)', 'Stardust (2007)']},
		'Heartwarming Coming-of-Age':
			{'description': 'Immerse yourself in the sweet, nostalgic safety of childhood memories and growing up.',
			'thematic_anchors': ['nostalgic settings', 'childhood friendships', 'retro eras', 'sentimental milestones'],
			'tonal_profile': ['nostalgic', 'sentimental', 'bittersweet', 'innocent', 'warm'],
			'cinematic_benchmarks': ['Stand by Me (1986)', 'The Way Way Back (2013)', 'Coda (2021)']},
		'Uplifting & Hopeful':
			{'description': 'You need a gentle, comforting reminder that kindness exists and humanity is inherently good.',
			'thematic_anchors': ['acts of kindness', 'emotional healing', 'second chances', 'unconditional compassion'],
			'tonal_profile': ['hopeful', 'positive', 'healing', 'profound', 'moving'],
			'cinematic_benchmarks': ['Ted Lasso (2020)', 'The Intouchables (2011)', 'Won\'t You Be My Neighbor? (2018)']},
		'Wholesome Found Family':
			{'description': 'Feel the warm embrace of tight-knit bonds, deep friendships, and absolute loyalty.',
			'thematic_anchors': ['found family tropes', 'unbreakable friendships', 'camaraderie', 'misfits banding together'],
			'tonal_profile': ['heartwarming', 'loyal', 'supportive', 'affectionate', 'comforting'],
			'cinematic_benchmarks': ['Parks and Recreation (2009)', 'Little Miss Sunshine (2006)', 'Brooklyn Nine-Nine (2013)']},
		'Amused & Ridiculous':
			{'description': 'You just want to switch off and laugh out loud at silly, goofy, low-effort nonsense.',
			'thematic_anchors': ['slapstick comedy', 'absurd scenarios', 'goofy gags', 'parodies and spoofs'],
			'tonal_profile': ['silly', 'goofy', 'hilarious', 'absurd', 'unpretentious'],
			'cinematic_benchmarks': ['Step Brothers (2008)', 'The Naked Gun (1988)', 'Airplane! (1980)']},
		'Triumph of the Spirit':
			{'description': 'Feel deeply motivated and inspired by characters overcoming adversity to achieve their dreams.',
			'thematic_anchors': ['overcoming adversity', 'underdog victories', 'pursuing dreams', 'inspiring true stories'],
			'tonal_profile': ['motivational', 'triumphant', 'inspiring', 'empowering', 'passionate'],
			'cinematic_benchmarks': ['The Pursuit of Happyness (2006)', 'Hidden Figures (2016)', 'Rocky (1976)']},
		'Tight-Knit Communities':
			{'description': 'Spend time in a comforting, familiar world centered around workplace antics or small-town life.',
			'thematic_anchors': ['small-town dynamics', 'workplace antics', 'eccentric neighbors', 'familiar recurring settings'],
			'tonal_profile': ['comforting', 'familiar', 'community-focused', 'witty'],
			'cinematic_benchmarks': ['Schitt\'s Creek (2015)', 'Gilmore Girls (2000)', 'The Office (2005)']},
		'Carefree Escapism':
			{'description': 'Ditch your responsibilities for a lighthearted, fun-filled journey, summer vacation, or road trip.',
			'thematic_anchors': ['summer vacations', 'road trips', 'lighthearted journeys', 'sun-drenched locations'],
			'tonal_profile': ['carefree', 'adventurous', 'vibrant', 'escapist', 'fun-filled'],
			'cinematic_benchmarks': ['Mamma Mia! (2008)', 'The Secret Life of Walter Mitty (2013)', 'Chef (2014)']}
	},
	'Sad & Introspective': {
		'Haunting Melancholy':
			{'description': 'You are navigating profound grief or loss and just need an atmospheric space to cry it out.',
			'thematic_anchors': ['profound grief', 'navigating loss', 'family tragedies', 'funerals and mourning'],
			'tonal_profile': ['melancholic', 'devastating', 'somber', 'heartbreaking', 'cathartic'],
			'cinematic_benchmarks': ['Manchester by the Sea (2016)', 'Ordinary People (1980)', 'Three Colors: Blue (1993)']},
		'Heartbroken Romances':
			{'description': 'Lean into the sharp, raw sting of romantic rejection, devastating breakups, or unrequited love.',
			'thematic_anchors': ['painful breakups', 'unrequited love', 'divorce and separation', 'fading relationships'],
			'tonal_profile': ['raw', 'unforgiving', 'romantically devastating', 'aching', 'bleak'],
			'cinematic_benchmarks': ['Blue Valentine (2010)', 'Marriage Story (2019)', 'Past Lives (2023)']},
		'Isolated & Disconnected':
			{'description': 'Find comfort and visibility in quiet stories of deep loneliness, alienation, and social disconnect.',
			'thematic_anchors': ['social isolation', 'profound loneliness', 'urban alienation', 'misunderstood outsiders'],
			'tonal_profile': ['lonely', 'detached', 'quiet', 'alienated', 'melancholic'],
			'cinematic_benchmarks': ['Her (2013)', 'Lost in Translation (2003)', 'Taxi Driver (1976)']},
		'Melancholic Sci-Fi':
			{'description': 'Ponder your purpose and the meaning of existence against a lonely, cold, or futuristic reality.',
			'thematic_anchors': ['existential dread', 'artificial intelligence loneliness', 'cosmic isolation', 'technological alienation'],
			'tonal_profile': ['existential', 'philosophical', 'cold', 'stark', 'introspective'],
			'cinematic_benchmarks': ['Blade Runner 2049 (2017)', 'Melancholia (2011)', 'Moon (2009)']},
		'Bittersweet Longing':
			{'description': 'Indulge in a beautiful, aching nostalgia for lost loves, missed opportunities, and times gone by.',
			'thematic_anchors': ['lost loves', 'missed opportunities', 'reminiscing on the past', 'yearning and nostalgia'],
			'tonal_profile': ['bittersweet', 'poignant', 'nostalgic', 'aching', 'romantic'],
			'cinematic_benchmarks': ['In the Mood for Love (2000)', 'Before Sunset (2004)', 'Brokeback Mountain (2005)']},
		'Poetic Slow Cinema':
			{'description': 'You feel completely drained and want a quiet, low-stimulus, deeply intimate character study.',
			'thematic_anchors': ['minimalist dialogue', 'meditative pacing', 'intimate character studies', 'subtle human interactions'],
			'tonal_profile': ['quiet', 'meditative', 'slow', 'minimalist', 'stark'],
			'cinematic_benchmarks': ['Drive My Car (2021)', 'Nomadland (2020)', 'Perfect Days (2023)']},
		'Haunted by the Past':
			{'description': 'Dwell quietly with characters frozen by intense regret, heavy guilt, and painful "what ifs."',
			'thematic_anchors': ['crushing guilt', 'secret shame', 'painful memories', 'unresolved mistakes'],
			'tonal_profile': ['haunted', 'regretful', 'repressed', 'tense', 'grim'],
			'cinematic_benchmarks': ['The Whispering Chorus (1918)', 'The Master (2012)', 'A History of Violence (2005)']},
		'Sombre Noir & Mystery':
			{'description': 'Sit quietly with a heavy, cold, rain-slicked atmosphere defined by bleak environments and moral decay.',
			'thematic_anchors': ['rain-slicked streets', 'cynical investigators', 'moral ambiguity', 'bleak urban landscapes'],
			'tonal_profile': ['cynical', 'bleak', 'cold', 'atmospheric', 'moody'],
			'cinematic_benchmarks': ['Se7en (1995)', 'Zodiac (2007)', 'Prisoners (2013)']},
		'Tragic Real-Life Stories':
			{'description': 'Walk intimately in the shoes of real historical figures enduring heartbreaking, monumental struggles.',
			'thematic_anchors': ['historical tragedies', 'war-time survival', 'biographical struggles', 'monumental human endurance'],
			'tonal_profile': ['profound', 'authentic', 'harrowing', 'dignified', 'heavy'],
			'cinematic_benchmarks': ['Schindler\'s List (1993)', '12 Years a Slave (2013)', 'The Pianist (2002)']},
		'Somber Melodies':
			{'description': 'Lose yourself in the bittersweet, melancholic world of troubled artists, musicians, and poetic struggles.',
			'thematic_anchors': ['troubled musicians', 'tortured artists', 'the cost of fame', 'creative self-destruction'],
			'tonal_profile': ['poetic', 'haunting', 'creative', 'obsessive', 'bittersweet'],
			'cinematic_benchmarks': ['Inside Llewyn Davis (2013)', 'Amadeus (1984)', 'Walk the Line (2005)']}
	},
	'Dreamy & Sensory Driven': {
		'Surreal Dream-Logic':
			{'description': 'Surrender your rational mind to hypnotic illusions, subconscious visions, and logic-bending journeys.',
			'thematic_anchors': ['subconscious visions', 'metaphorical journeys', 'non-linear storytelling', 'bizarre logic'],
			'tonal_profile': ['hypnotic', 'surreal', 'disorienting', 'dreamlike', 'hallucinatory'],
			'cinematic_benchmarks': ['Mulholland Drive (2001)', 'Inception (2010)', 'Eternal Sunshine of the Spotless Mind (2004)']},
		'Sleek Neon Noir':
			{'description': 'Immerse yourself in a ultra-stylised, dark, rain-slicked world of brooding loners and glowing city streets.',
			'thematic_anchors': ['neon aesthetics', 'rain-slicked streets', 'brooding antiheroes', 'underworld syndicates'],
			'tonal_profile': ['slick', 'atmospheric', 'moody', 'electronic', 'cynical'],
			'cinematic_benchmarks': ['Drive (2011)', 'Blade Runner (1982)', 'Chongqing Express (1994)']},
		'Eerie & Supernatural Creep':
			{'description': 'Seek out a quiet, skin-crawling gothic chill full of hidden curses, historic mansions, and creeping dread.',
			'thematic_anchors': ['gothic mansions', 'ancestral curses', 'ghostly apparitions', 'forbidden folklore'],
			'tonal_profile': ['unsettling', 'creepy', 'foreboding', 'gothic', 'sinister'],
			'cinematic_benchmarks': ['The Others (2001)', 'Crimson Peak (2015)', 'The Innocents (1961)']},
		'Sun-Drenched Memories':
			{'description': 'Drift aimlessly through hazy, warm summer memory sequences and beautiful romantic nostalgia.',
			'thematic_anchors': ['golden hour cinematography', 'summer romances', 'poetic memory sequences', 'hazy nostalgia'],
			'tonal_profile': ['sun-drenched', 'wistful', 'romantic', 'hazy', 'poetic'],
			'cinematic_benchmarks': ['Call Me by Your Name (2017)', 'The Virgin Suicides (1999)', 'Before Sunrise (1995)']},
		'Stark Minimalist Solitude':
			{'description': 'Escape to wide, clean, empty landscapes and isolated environments where silence dominates the frame.',
			'thematic_anchors': ['barren snowscapes', 'vast desert expanses', 'isolated characters', 'minimal dialogue'],
			'tonal_profile': ['stark', 'minimalist', 'remote', 'quiet', 'desolate'],
			'cinematic_benchmarks': ['Fargo (1996)', 'The Revenant (2015)', 'Paris, Texas (1984)']},
		'Psychedelic Mind-Melts':
			{'description': 'Intoxicate your vision with vibrant, kaleidoscopic colors, altered states of consciousness, and vivid hallucinations.',
			'thematic_anchors': ['altered states of consciousness', 'vivid hallucinations', 'kaleidoscopic color palettes', 'mind-bending imagery'],
			'tonal_profile': ['psychedelic', 'vibrant', 'trippy', 'manic', 'dazzling'],
			'cinematic_benchmarks': ['Enter the Void (2009)', 'Fear and Loathing in Las Vegas (1998)', 'Paprika (2006)']},
		'Dark Passion & Macabre Romance':
			{'description': 'Indulge in a morbid, deeply intense, and beautifully tragic romance dripping with gothic drama.',
			'thematic_anchors': ['morbid obsessions', 'vampiric lore', 'forbidden attraction', 'tragic romantic endings'],
			'tonal_profile': ['macabre', 'sensual', 'dark', 'intense', 'melodramatic'],
			'cinematic_benchmarks': ['Bram Stoker\'s Dracula (1992)', 'Only Lovers Left Alive (2013)', 'Phantom Thread (2017)']},
		'Cosmic & Space-Bound Dreams':
			{'description': 'Feel beautifully weightless and infinitely small drifting through stargazing, interstellar space-travel narratives.',
			'thematic_anchors': ['interstellar travel', 'cosmic silence', 'weightless drifting', 'existential stargazing'],
			'tonal_profile': ['cosmic', 'majestic', 'weightless', 'profound', 'ethereal'],
			'cinematic_benchmarks': ['2001: A Space Odyssey (1968)', 'Interstellar (2014)', 'Ad Astra (2019)']},
		'Atmospheric Slow-Burn Horror':
			{'description': 'Let yourself be slowly pulled under by a heavy, inescapable, cult-like mood with zero cheap jump scares.',
			'thematic_anchors': ['creeping dread', 'pagan or folk cults', 'unsettling isolation', 'inescapable heavy atmosphere'],
			'tonal_profile': ['slow-burn', 'oppressive', 'visceral', 'disturbing', 'hypnotic'],
			'cinematic_benchmarks': ['Midsommar (2019)', 'The Witch (2015)', 'The Shining (1980)']},
		'Ethereal High Adventures':
			{'description': 'Embark on sweeping, visually spectacular fantasy quests through unmapped, mythic, and breathtaking nature.',
			'thematic_anchors': ['sweeping fantasy quests', 'breathtaking natural landscapes', 'ancient civilizations', 'mythic journeys'],
			'tonal_profile': ['ethereal', 'majestic', 'epic', 'wondrous', 'spectacular'],
			'cinematic_benchmarks': ['The Lord of the Rings: The Fellowship of the Ring (2001)', 'Avatar (2009)', 'Princess Mononoke (1997)']}
	},
	'Curious & Intellectual': {
		'Morally Conflicted Dilemmas':
			{'description': 'Debate what is right and wrong with characters forced into impossible ethical choices.',
			'thematic_anchors': ['impossible ethical choices', 'moral grey areas', 'unintended consequences', 'crisis of conscience'],
			'tonal_profile': ['thought-provoking', 'tense', 'analytical', 'compromising'],
			'cinematic_benchmarks': ['Sophie\'s Choice (1982)', 'A Separation (2011)', 'Gone Baby Gone (2007)']},
		'Deep-Dive Psychological Profiles':
			{'description': 'Peel back the layers of complex, brilliant, or deeply flawed minds in intimate character studies.',
			'thematic_anchors': ['brilliant but flawed minds', 'uncompromising obsession', 'intimate character studies', 'eccentric geniuses'],
			'tonal_profile': ['intense', 'deeply psychological', 'fascinating', 'uncompromising'],
			'cinematic_benchmarks': ['There Will Be Blood (2007)', 'The Social Network (2010)', 'Tár (2022)']},
		'Conspiracy & Whistleblowers':
			{'description': 'Question authority and follow paranoiac paths to uncover hidden corporate or government cover-ups.',
			'thematic_anchors': ['government cover-ups', 'corporate whistleblowers', 'systemic paranoia', 'uncovering hidden truths'],
			'tonal_profile': ['paranoid', 'suspenseful', 'cynical', 'urgent'],
			'cinematic_benchmarks': ['All the President\'s Men (1976)', 'The Insider (1999)', 'Spotlight (2015)']},
		'Cerebral Crime Chronicles':
			{'description': 'Piece together intricate psychological and criminal puzzles where the intellect is the primary weapon.',
			'thematic_anchors': ['psychological profiling', 'serial killer behavioral analysis', 'fbi procedurals', 'intellectual cat-and-mouse games'],
			'tonal_profile': ['clinical', 'dark', 'methodical', 'intellectual'],
			'cinematic_benchmarks': ['Mindhunter (2017)', 'The Silence of the Lambs (1991)', 'Memories of Murder (2003)']},
		'Inquisitive Investigative Mysteries':
			{'description': 'Step into the shoes of a determined detective or journalist piecing together a real-world puzzle.',
			'thematic_anchors': ['journalistic investigation', 'uncovering puzzles', 'dogged investigative reporting', 'unravelling intricate clues'],
			'tonal_profile': ['methodical', 'engrossing', 'determined', 'grounded'],
			'cinematic_benchmarks': ['Zodiac (2007)', 'Chinatown (1974)', 'Knives Out (2019)']},
		'Philosophical Thought Experiments':
			{'description': 'Challenge your core assumptions about humanity, perception, and reality with deeply cerebral narratives.',
			'thematic_anchors': ['existential thought experiments', 'challenging perceptions of reality', 'nature of humanity', 'metaphysical paradoxes'],
			'tonal_profile': ['cerebral', 'philosophical', 'profound', 'perceptive'],
			'cinematic_benchmarks': ['The Truman Show (1998)', 'Synecdoche, New York (2008)', 'The Seventh Seal (1957)']},
		'Courtroom & Legal Battles':
			{'description': 'Weigh raw evidence and watch razor-sharp legal minds debate fairness, law, and ultimate justice.',
			'thematic_anchors': ['high-stakes legal trials', 'courtroom cross-examinations', 'debating legal fairness', 'unravelling raw evidence'],
			'tonal_profile': ['sharp', 'dramatic', 'eloquent', 'gripping'],
			'cinematic_benchmarks': ['12 Angry Men (1957)', 'A Few Good Men (1992)', 'Anatomy of a Fall (2023)']},
		'Cutting-Edge Tech Ethics':
			{'description': 'Ponder hard logic, artificial intelligence, and the deep ethical consequences of rapid human advancement.',
			'thematic_anchors': ['artificial intelligence consciousness', 'technological ethics', 'hard scientific logic', 'human advancement consequences'],
			'tonal_profile': ['clinical', 'futuristic', 'cautionary', 'sleek'],
			'cinematic_benchmarks': ['Ex Machina (2014)', 'Her (2013)', 'Black Mirror (2011)']},
		'Spiritually Searching':
			{'description': 'Grapple with deep questions of faith, existential doubt, theological mystery, and the human soul.',
			'thematic_anchors': ['existential faith crisis', 'theological mystery', 'grappling with the human soul', 'religious devotion and doubt'],
			'tonal_profile': ['spiritual', 'reverent', 'searching', 'profound'],
			'cinematic_benchmarks': ['First Reformed (2017)', 'The Tree of Life (2011)', 'Silence (2016)']},
		'Sociopolitical Commentary':
			{'description': 'Absorb the raw, thought-provoking realities of deep cultural divides, wealth inequality, and class struggles.',
			'thematic_anchors': ['wealth inequality', 'class warfare dynamics', 'sociopolitical satire', 'systemic cultural divides'],
			'tonal_profile': ['sharp', 'satirical', 'uncomfortable', 'revealing'],
			'cinematic_benchmarks': ['Parasite (2019)', 'Triangle of Sadness (2022)', 'Snowpiercer (2013)']}
	},
	'Time Travelling Escapism': {
		'Regal & Elite':
			{'description': 'You want to feel the opulence and high-society drama of royalty.',
			'thematic_anchors': ['royal court intrigue', 'monarchies and empires', 'palace life', 'aristocratic power struggles'],
			'tonal_profile': ['opulent', 'dramatic', 'stately', 'prestigious'],
			'cinematic_benchmarks': ['The Crown (2016)', 'The Favourite (2018)', 'The King\'s Speech (2010)']},
		'Gritty & Primal':
			{'description': 'You want to strip away modern life for mud, swords, and survival.',
			'thematic_anchors': ['medieval combat', 'castle sieges', 'brutal survival instincts', 'feudal warrior culture'],
			'tonal_profile': ['brutal', 'visceral', 'muddy', 'raw', 'uncompromising'],
			'cinematic_benchmarks': ['The Northman (2022)', 'Gladiator (2000)', 'The Last Kingdom (2015)']},
		'Gilded Glamour & High Society':
			{'description': 'Escape into a world of dazzling wealth, lavish parties, and elite social scandals.',
			'thematic_anchors': ['high society scandals', 'lavish costume balls', 'generational wealth', 'forbidden class romance'],
			'tonal_profile': ['glamorous', 'scandalous', 'lavish', 'elegant'],
			'cinematic_benchmarks': ['Downton Abbey (2010)', 'The Great Gatsby (2013)', 'Bridgerton (2020)']},
		'Swashbuckling & High Adventure':
			{'description': 'You want the classic romantic thrill of high-seas voyages, hidden treasure, and daring escapes.',
			'thematic_anchors': ['high-seas seafaring voyages', 'hidden treasure maps', 'pirate lore', 'daring high-stakes escapes'],
			'tonal_profile': ['adventurous', 'thrilling', 'romantic', 'escapist'],
			'cinematic_benchmarks': ['Pirates of the Caribbean: The Curse of the Black Pearl (2003)', 'Master and Commander (2003)', 'Black Sails (2014)']},
		'Lawless & Untamed':
			{'description': 'You want to escape into a wild, unmapped frontier where raw survival and grit rule the land.',
			'thematic_anchors': ['wild west frontiers', 'bounty hunting runs', 'outlaw syndicates', 'desert ranch skirmishes'],
			'tonal_profile': ['gritty', 'lawless', 'stark', 'rugged'],
			'cinematic_benchmarks': ['1883 (2021)', 'True Grit (2010)', 'Unforgiven (1992)']},
		'Wartime Camaraderie':
			{'description': 'You want to feel the intense brotherly bonds born of crisis.',
			'thematic_anchors': ['battlefield frontline brotherhood', 'military tactics', 'trench warfare conditions', 'wartime survival'],
			'tonal_profile': ['intense', 'harrowing', 'loyal', 'profound'],
			'cinematic_benchmarks': ['Band of Brothers (2001)', '1917 (2019)', 'Saving Private Ryan (1998)']},
		'Ancient Mysticism':
			{'description': 'You want to feel the mythic weight of lost empires.',
			'thematic_anchors': ['ancient lost empires', 'mythological lore', 'roman or greek civilizations', 'gods and pharaohs'],
			'tonal_profile': ['epic', 'mythic', 'monumental', 'majestic'],
			'cinematic_benchmarks': ['Rome (2005)', 'Troy (2004)', 'Spartacus (2010)']},
		'Retro-Cool Noir':
			{'description': 'Step into a slick, stylized mid-century world of hard-boiled detectives, neon streets, and dark secrets.',
			'thematic_anchors': ['mid-century jazz lounges', 'hard-boiled investigators', 'mob underworld operations', 'vintage detective investigations'],
			'tonal_profile': ['slick', 'stylized', 'cynical', 'moody'],
			'cinematic_benchmarks': ['L.A. Confidential (1997)', 'Chinatown (1974)', 'Perry Mason (2020)']},
		'Biographical Empathy':
			{'description': 'You want to intimately walk in the shoes of a real historical figure.',
			'thematic_anchors': ['real historical life accounts', 'grounded biological portraits', 'monumental real-life struggles', 'historical journals'],
			'tonal_profile': ['authentic', 'intimate', 'revelatory', 'grounded'],
			'cinematic_benchmarks': ['Oppenheimer (2023)', 'The King (2019)', 'Lincoln (2012)']},
		'Nostalgic Vintage Charm':
			{'description': 'Escape into the sweet, romanticized warmth and stylistic flair of bygone early-to-mid 20th century decades.',
			'thematic_anchors': ['retro mid-century fashion', 'vintage lifestyle aesthetic', 'small-town nostalgia', 'classic golden-age pacing'],
			'tonal_profile': ['warm', 'nostalgic', 'charming', 'wistful'],
			'cinematic_benchmarks': ['The Notebook (2004)', 'Midnight in Paris (2011)', 'The Marvelous Mrs. Maisel (2017)']}
	},
	'Rebellious & Edgy': {
		'Absurdist':
			{'description': 'You feel like nothing makes sense, so you want to embrace total surreal nonsense.',
			'thematic_anchors': ['existential nonsense', 'bizarre logic-bending scenarios', 'surreal imagery', 'eccentric world-building'],
			'tonal_profile': ['absurd', 'surreal', 'weird', 'unpredictable', 'disorienting'],
			'cinematic_benchmarks': ['Everything Everywhere All at Once (2022)', 'Swiss Army Man (2016)', 'Being John Malkovich (1999)']},
		'Wicked Black Comedy':
			{'description': 'Satisfy your inner cynic with razor-sharp satire, pitch-black irony, and terrible people misbehaving.',
			'thematic_anchors': ['pitch-black humor', 'terrible human behavior', 'cynical social satires', 'subversive greed plots'],
			'tonal_profile': ['cynical', 'razor-sharp', 'subversive', 'wicked', 'hilarious'],
			'cinematic_benchmarks': ['The Wolf of Wall Street (2013)', 'Succession (2018)', 'The Banshees of Inisherin (2022)']},
		'Cringe-Seeking':
			{'description': 'You want to squirm in hilariously awkward discomfort and second-hand embarrassment.',
			'thematic_anchors': ['social humiliation', 'extreme awkwardness', 'deadpan comedy setups', 'uncomfortable confrontations'],
			'tonal_profile': ['cringe-inducing', 'awkward', 'uncomfortable', 'hilarious', 'excruciating'],
			'cinematic_benchmarks': ['The Curse (2023)', 'Borat (2006)', 'Fleabag (2016)']},
		'Guns-Blazing Outlaws':
			{'description': 'Ride along with slick, rule-breaking anti-heroes, criminal crews, and high-stakes heist masterminds.',
			'thematic_anchors': ['criminal underworld syndicates', 'charismatic bank robbers', 'mafia power dynamics', 'elaborate street hustles'],
			'tonal_profile': ['slick', 'rebellious', 'high-stakes', 'badass', 'thrilling'],
			'cinematic_benchmarks': ['The Gentlemen (2019)', 'Snatch (2000)', 'Breaking Bad (2008)']},
		'Gritty Counter-Culture':
			{'description': 'Tap into raw, uncompromising street-level rebellion against corporate greed and conventional rules.',
			'thematic_anchors': ['anti-establishment uprisings', 'cyberpunk underground hackers', 'corporate subversion', 'anarchist movements'],
			'tonal_profile': ['gritty', 'uncompromising', 'anarchic', 'raw', 'edgy'],
			'cinematic_benchmarks': ['Mr. Robot (2015)', 'Fight Club (1999)', 'Trainspotting (1996)']},
		'Macabre Curiosity':
			{'description': 'You are fascinated by the grotesque, weird, forbidden, and deliciously dark.',
			'thematic_anchors': ['grotesque mysteries', 'morbid fascination plots', 'gothic family aesthetics', 'twisted physical scenarios'],
			'tonal_profile': ['macabre', 'morbid', 'darkly artistic', 'creepy', 'fascinating'],
			'cinematic_benchmarks': ['The Addams Family (1991)', 'Beetlejuice (1988)', 'What We Do in the Shadows (2014)']},
		'Campy':
			{'description': 'You want to enjoy things that are intentionally trashy, loud, theatrical, and cult-classic material.',
			'thematic_anchors': ['b-movie visual choices', 'intentionally cheesy effects', 'theatrical monster performances', 'trashy plot points'],
			'tonal_profile': ['campy', 'cult-classic', 'loud', 'theatrical', 'unpretentious'],
			'cinematic_benchmarks': ['The Rocky Horror Picture Show (1975)', 'Evil Dead II (1987)', 'M3GAN (2022)']},
		'Shock-Seeking':
			{'description': 'You want to see social taboos and boundaries pushed to their absolute limits.',
			'thematic_anchors': ['provocative social experiments', 'breaking cultural taboos', 'disturbing psychological insights', 'boundary-pushing narrative twists'],
			'tonal_profile': ['provocative', 'shocking', 'disturbing', 'intense', 'polarizing'],
			'cinematic_benchmarks': ['Saltburn (2023)', 'Parasite (2019)', 'The Skin I Live In (2011)']},
		'Unapologetically Weird':
			{'description': 'Celebrate eccentric, bizarre outsiders who completely refuse to fit into normal society.',
			'thematic_anchors': ['unconventional lifestyle choices', 'eccentric misfit dynamics', 'quirky personal paths', 'proudly odd protagonists'],
			'tonal_profile': ['unapologetic', 'quirky', 'endearing', 'bizarre', 'eccentric'],
			'cinematic_benchmarks': ['Napoleon Dynamite (2004)', 'The Lobster (2015)', 'Wednesday (2022)']},
		'Slick & Stylized Neon Thrills':
			{'description': 'Immerse yourself in a high-octane world of hyper-vibrant crime, driving soundswells, and beautiful violence.',
			'thematic_anchors': ['neon cinematography', 'pulse-pounding soundtracks', 'stylized action choreography', 'criminal antiheroes'],
			'tonal_profile': ['slick', 'vibrant', 'kinetic', 'stylish', 'hypnotic'],
			'cinematic_benchmarks': ['Drive (2011)', 'John Wick (2014)', 'Nightcrawler (2014)']}
	},
	'Mind Boggled & Disoriented': {
		'Paranoid Thriller':
			{'description': 'You feel like eyes are everywhere and you absolutely cannot trust anyone around you.',
			'thematic_anchors': ['covert surveillance networks', 'systemic paranoia', 'hidden conspiracies', 'spied-on protagonists'],
			'tonal_profile': ['paranoid', 'suspenseful', 'cynical', 'claustrophobic'],
			'cinematic_benchmarks': ['The Conversation (1974)', 'Enemy of the State (1998)', 'Shutter Island (2010)']},
		'The Illusion of Reality':
			{'description': 'Question everything around you as characters discover their world is a simulation, dream, or illusion.',
			'thematic_anchors': ['virtual reality simulations', 'manufactured illusions', 'altered sensory perceptions', 'matrix structures'],
			'tonal_profile': ['existential', 'surreal', 'disorienting', 'mind-bending'],
			'cinematic_benchmarks': ['The Matrix (1999)', 'The Truman Show (1998)', 'Dark City (1998)']},
		'Ticking Time Loops':
			{'description': 'Live, die, repeat. Escape the exhausting nightmare of being stuck in a cyclical temporal loop.',
			'thematic_anchors': ['temporal time loops', 'cyclical paradoxes', 'rewinding timelines', 'preventing future events'],
			'tonal_profile': ['frantic', 'exhausting', 'clever', 'repetitive-by-design'],
			'cinematic_benchmarks': ['Groundhog Day (1993)', 'Edge of Tomorrow (2014)', 'Source Code (2011)']},
		'Claustrophobic Survival':
			{'description': 'Feel the walls closing in with characters trapped in single-room puzzles and tight, inescapable spaces.',
			'thematic_anchors': ['single-room survival puzzles', 'tight confined bunkers', 'inescapable physical traps', 'claustrophobic set pieces'],
			'tonal_profile': ['claustrophobic', 'anxiety-inducing', 'tense', 'urgent'],
			'cinematic_benchmarks': ['Cube (1997)', 'Room (2015)', 'Buried (2010)']},
		'Gaslit & Manipulated':
			{'description': 'Experience the suffocating tension of malicious psychological games and calculated deception.',
			'thematic_anchors': ['calculated psychological gaslighting', 'malicious mind games', 'deceptive relationships', 'unravelling lies'],
			'tonal_profile': ['suffocating', 'tense', 'unsettling', 'psychological'],
			'cinematic_benchmarks': ['Gaslight (1944)', 'The Invisible Man (2020)', 'Gone Girl (2014)']},
		'Vertigo Timelines':
			{'description': 'Intoxicate your brain with non-linear, fragmented puzzles and dizzying time jumps.',
			'thematic_anchors': ['non-linear timeline fragmentation', 'dizzying flashbacks', 'interwoven chronological puzzles', 'unreliable timelines'],
			'tonal_profile': ['fragmented', 'dizzying', 'intricate', 'analytical'],
			'cinematic_benchmarks': ['Memento (2000)', 'Inception (2010)', 'Arrival (2016)']},
		'Obsessive Descent':
			{'description': 'Track the brilliant, terrifying downward spiral of a mind completely consumed by a single fixation.',
			'thematic_anchors': ['destructive creative fixations', 'downward mental spirals', 'uncompromising obsession', 'loss of structural sanity'],
			'tonal_profile': ['manic', 'terrifying', 'obsessive', 'intense'],
			'cinematic_benchmarks': ['Pi (1998)', 'Black Swan (2010)', 'The Number 23 (2007)']},
		'Fractured Mind':
			{'description': 'See the world through a deeply unstable lens where your own narrator cannot be trusted.',
			'thematic_anchors': ['unreliable narrators', 'severe identity crises', 'amnesia and memory loss', 'shattered personality states'],
			'tonal_profile': ['unstable', 'fractured', 'disorienting', 'untrustworthy'],
			'cinematic_benchmarks': ['Fight Club (1999)', 'American Psycho (2000)', 'The Machinist (2004)']},
		'Surreal Cosmic Madness':
			{'description': 'Surrender your understanding of physics to terrifying extra-dimensional anomalies and logic-breaking cosmic forces.',
			'thematic_anchors': ['extra-dimensional anomalies', 'cosmic entities', 'breaking physical dimensions', 'unfathomable geometric spaces'],
			'tonal_profile': ['cosmic', 'overwhelming', 'existential', 'hallucinatory'],
			'cinematic_benchmarks': ['Annihilation (2018)', 'Interstellar (2014)', 'Coherence (2013)']},
		'The Twisted Final Act':
			{'description': 'Watch a carefully built narrative paradigm get completely shattered by a single, reality-altering plot twist.',
			'thematic_anchors': ['reality-altering plot twists', 'shattered assumptions', 'subverted audience expectations', 'deep conceptual secrets'],
			'tonal_profile': ['shocking', 'subversive', 'clever', 'mind-boggling'],
			'cinematic_benchmarks': ['The Sixth Sense (1999)', 'The Usual Suspects (1995)', 'The Prestige (2006)']}
	},
	'Thrill Seeking & Terrified': {
		'Visceral Survival Horror':
			{'description': 'Face your most primal fears tracking desperate characters hunted by unrelenting, physical monsters.',
			'thematic_anchors': ['monster features', 'unrelenting pursuits', 'gory survival setups', 'creature encounters'],
			'tonal_profile': ['visceral', 'terrifying', 'gory', 'pulse-pounding'],
			'cinematic_benchmarks': ['Alien (1979)', 'A Quiet Place (2018)', 'The Descent (2005)']},
		'Slow-Burn Psychological Dread':
			{'description': 'Let a heavy, invisible panic slowly crawl under your skin with zero cheap jump scares.',
			'thematic_anchors': ['creeping panic', 'implied threats', 'unsettling audio design', 'domestic paranoia'],
			'tonal_profile': ['unsettling', 'dread-inducing', 'slow-burn', 'heavy'],
			'cinematic_benchmarks': ['It Follows (2014)', 'Hereditary (2018)', 'The Babadook (2014)']},
		'Paranormal & Demonic Chills':
			{'description': 'Turn off the lights for a classic, terrifying encounter with hidden spirits, curses, and malicious entities.',
			'thematic_anchors': ['haunted houses', 'demonic possessions', 'malevolent spirits', 'occult investigations'],
			'tonal_profile': ['frightening', 'gothic', 'sinister', 'eerie'],
			'cinematic_benchmarks': ['The Conjuring (2013)', 'The Exorcist (1973)', 'Insidious (2010)']},
		'Found-Footage Realism':
			{'description': 'Immerse yourself in the raw, terrifying illusion of real, first-person panic caught on shaky cameras.',
			'thematic_anchors': ['first-person cameras', 'lost footage tropes', 'shaky camera realism', 'mock documentary setups'],
			'tonal_profile': ['raw', 'immersive', 'frantic', 'authentic'],
			'cinematic_benchmarks': ['The Blair Witch Project (1999)', 'Paranormal Activity (2007)', 'REC (2007)']},
		'Home Invasion Panic':
			{'description': 'Experience the terrifying violation of your safest spaces being breached by malicious forces.',
			'thematic_anchors': ['masked intruders', 'trapped in a house', 'defending your home', 'silent stalkers'],
			'tonal_profile': ['intense', 'suffocating', 'terrifying', 'grounded'],
			'cinematic_benchmarks': ['The Strangers (2008)', 'Don\'t Breathe (2016)', 'Hush (2016)']},
		'Splatter & Gore Spectacle':
			{'description': 'Indulge a morbid appetite for over-the-top, highly theatrical, and deliciously bloody survival chaos.',
			'thematic_anchors': ['extreme physical gore', 'creative trap devices', 'uncompromising body horror', 'blood splatters'],
			'tonal_profile': ['visceral', 'shocking', 'theatrical', 'grotesque'],
			'cinematic_benchmarks': ['Saw (2004)', 'The Fly (1986)', 'Evil Dead (2013)']},
		'Tense Cat-and-Mouse Chase':
			{'description': 'Match your heart rate to a relentless, high-stakes hunt where one wrong move means instant death.',
			'thematic_anchors': ['cunning serial killers', 'dogged pursuits', 'highway stalkers', 'survival tactics'],
			'tonal_profile': ['suspenseful', 'relentless', 'gripping', 'anxiety-inducing'],
			'cinematic_benchmarks': ['No Country for Old Men (2007)', 'Joy Ride (2001)', 'The Invisible Man (2020)']},
		'Folk Horror & Cult Isolation':
			{'description': 'Get lost in remote, tight-knit communities harboring deeply sinister, ancient pagan secrets.',
			'thematic_anchors': ['isolated pagan villages', 'sinister community rituals', 'ancient folklore', 'sacrificial plots'],
			'tonal_profile': ['creepy', 'atmospheric', 'deceptive', 'bizarre'],
			'cinematic_benchmarks': ['Midsommar (2019)', 'The Wicker Man (1973)', 'The Ritual (2017)']},
		'Claustrophobic Survival Traps':
			{'description': 'Feel the crushing weight of being physically pinned down or trapped in an inescapable environment.',
			'thematic_anchors': ['buried alive setups', 'confined survival rooms', 'submerged environments', 'tight spaces'],
			'tonal_profile': ['claustrophobic', 'suffocating', 'tense', 'urgent'],
			'cinematic_benchmarks': ['Buried (2010)', 'Crawl (2019)', '127 Hours (2010)']},
		'Sci-Fi Techno-Horror':
			{'description': 'Watch humanity get absolute crushed by its own hubris, rogue technology, or cold alien encounters.',
			'thematic_anchors': ['rogue artificial intelligence', 'body mutations', 'cold deep-space terror', 'failed scientific breakthroughs'],
			'tonal_profile': ['clinical', 'bleak', 'futuristic', 'stark'],
			'cinematic_benchmarks': ['The Thing (1982)', 'Ex Machina (2014)', 'Event Horizon (1997)']}
	},
	'Empowered & Social Seeking': {
		'Corporate Cutthroats & Ambition':
			{'description': 'Feed your inner drive watching ruthless, hyper-articulate power players climb to the top of the financial world.',
			'thematic_anchors': ['corporate boardroom takeovers', 'hyper-articulate business negotiations', 'insane greed arcs', 'financial schemes'],
			'tonal_profile': ['sharp', 'ambitious', 'cynical', 'fast-paced'],
			'cinematic_benchmarks': ['Succession (2018)', 'The Wolf of Wall Street (2013)', 'Margin Call (2011)']},
		'Political Chess & Intrigue':
			{'description': 'Indulge in a cold, tactical world of strategic backstabbing, hidden leverage, and systemic manipulation.',
			'thematic_anchors': ['political backstabbing', 'hidden government manipulation', 'campaign strategy operations', 'blackmail networks'],
			'tonal_profile': ['tactical', 'cold', 'sharp', 'engrossing'],
			'cinematic_benchmarks': ['House of Cards (2013)', 'The Ides of March (2011)', 'The West Wing (1999)']},
		'The Underdog Rise & Hustle':
			{'description': 'Feel a surge of motivation watching clever outcasts scratch, claw, and outsmart the system to build an empire.',
			'thematic_anchors': ['street hustling operations', 'clever entrepreneurial startups', 'outsmarting corrupt authorities', 'rags-to-riches arcs'],
			'tonal_profile': ['motivational', 'clever', 'energetic', 'empowering'],
			'cinematic_benchmarks': ['The Social Network (2010)', 'Moneyball (2011)', 'Joy (2015)']},
		'High-Society Scandals & Gossip':
			{'description': 'Peer behind the pristine curtain of extreme wealth to watch elite families tear each other apart over secrets.',
			'thematic_anchors': ['elite social gossip', 'extravagant family dynasties', 'reputation destruction', 'forbidden wealthy romances'],
			'tonal_profile': ['glamorous', 'scandalous', 'dramatic', 'addictive'],
			'cinematic_benchmarks': ['Gossip Girl (2007)', 'The White Lotus (2021)', 'Big Little Lies (2017)']},
		'Mafia & Criminal Empires':
			{'description': 'Witness the grand, operatic rise and tragic fall of highly structured family crime syndicates.',
			'thematic_anchors': ['organized crime syndicates', 'mafia family loyalty', 'underworld territory wars', 'criminal enterprise management'],
			'tonal_profile': ['operatic', 'gritty', 'prestigious', 'intense'],
			'cinematic_benchmarks': ['The Godfather (1972)', 'Goodfellas (1990)', 'The Sopranos (1999)']},
		'Elite Sports Competitions':
			{'description': 'Channel high-stakes competitive energy through the blood, sweat, and tears of elite athletes chasing glory.',
			'thematic_anchors': ['championship athletic training', 'high-stakes tournament finals', 'locker-room camaraderie', 'bitter sporting rivalries'],
			'tonal_profile': ['triumphant', 'passionate', 'motivational', 'dramatic'],
			'cinematic_benchmarks': ['Formula 1: Drive to Survive (2019)', 'The Last Dance (2020)', 'Creed (2015)']},
		'Witty Workplace Banter':
			{'description': 'Relax into a sharp, highly social environment defined by fast-talking professionals who love their jobs.',
			'thematic_anchors': ['fast-talking workplace antics', 'witty ensemble dynamics', 'professional chemistry', 'competent characters'],
			'tonal_profile': ['witty', 'smart', 'engaging', 'comforting'],
			'cinematic_benchmarks': ['Suits (2011)', 'The Newsroom (2012)', 'Mad Men (2007)']},
		'Military Tactical Operations':
			{'description': 'Feel the intense, quiet competence of hyper-focused elite units executing complex real-world missions.',
			'thematic_anchors': ['elite special forces operations', 'high-stakes tactical planning', 'brotherhood under fire', 'military rescue missions'],
			'tonal_profile': ['clinical', 'intense', 'competent', 'patriotic'],
			'cinematic_benchmarks': ['Zero Dark Thirty (2012)', 'Sicario (2015)', 'Black Hawk Down (2001)']},
		'Legal & Investigative Strategy':
			{'description': 'Watch brilliant legal and journalistic teams combine their brains to outmaneuver massive, corrupt entities.',
			'thematic_anchors': ['uncovering systematic corruption', 'high-stakes legal strategy', 'investigative newsroom operations', 'depositions'],
			'tonal_profile': ['methodical', 'gripping', 'righteous', 'sharp'],
			'cinematic_benchmarks': ['Spotlight (2015)', 'Erin Brockovich (2000)', 'Michael Clayton (2007)']},
		'Epic Historical Conquests':
			{'description': 'Witness monumental, sweeping human history shaped by legendary leaders commanding entire civilizations.',
			'thematic_anchors': ['sweeping battlefield conquests', 'empire-building strategies', 'legendary historical leaders', 'monumental legacy plots'],
			'tonal_profile': ['epic', 'monumental', 'prestigious', 'majestic'],
			'cinematic_benchmarks': ['Alexander (2004)', 'Kingdom of Heaven (2005)', 'Napoleon (2023)']}
	} 
	}

def mood_colors():
	return {
	'Restless & Hyperactive': 'FFFF4500',
	'Joyful & Comfort Seeking': 'FFFFC125',
	'Sad & Introspective': 'FF00E5FF',
	'Dreamy & Sensory Driven': 'FFD9A6FF',
	'Curious & Intellectual': 'FFFF7F00',
	'Time Travelling Escapism': 'FFDFFF00',
	'Rebellious & Edgy': 'FF00FF66',
	'Mind Boggled & Disoriented': 'FF7B00FF',
	'Thrill Seeking & Terrified': 'FFFF003F',
	'Empowered & Social Seeking': 'FFFE019A'
	}
